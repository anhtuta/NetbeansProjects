package nguyenvanquan7826;

public class Main {
	public static void main(String[] args){
		new CaroFrame();
	}
}
